package com.capstone.backend.domain;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class DailyMeals {
    private List<String> breakfast;
    private List<String> lunch;
    private List<String> dinner;

    // getters, setters
}
