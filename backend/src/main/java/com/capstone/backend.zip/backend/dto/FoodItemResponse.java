package com.capstone.backend.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter @Setter
public class FoodItemResponse {
    private String name;
    private String imageUrl;
    private List<NutrientIntake> nutrients;
    private List<String> ingredients;
    private String recipe;
}
